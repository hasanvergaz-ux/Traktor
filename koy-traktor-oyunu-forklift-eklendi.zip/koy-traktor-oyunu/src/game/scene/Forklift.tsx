import { useGLTF } from "@react-three/drei";
import { useMemo } from "react";
import * as THREE from "three";
import { asset } from "../assets";
import { heightAt } from "../sim/world";

/** Parked forklift prop. Kept separate from the tractor controls/physics. */
export function Forklift() {
  const gltf = useGLTF(asset("forklift.glb"));
  const model = useMemo(() => {
    const clone = gltf.scene.clone(true);
    const bounds = new THREE.Box3().setFromObject(clone);
    const size = bounds.getSize(new THREE.Vector3());
    const center = bounds.getCenter(new THREE.Vector3());
    const scale = 5 / Math.max(size.x, size.y, size.z);
    clone.scale.setScalar(scale);
    clone.position.set(-center.x * scale, -bounds.min.y * scale, -center.z * scale);
    return clone;
  }, [gltf.scene]);

  const x = -69;
  const z = 24;
  return <primitive object={model} position={[x, heightAt(x, z), z]} rotation-y={Math.PI / 2} />;
}
